package stu.parker.finalprogram.payrollSearch;

import java.util.Scanner;

/*
 * Programmer:Craig Parker
 * File: MainClass.java
 * Purp: Provide a searchable employee lookup compleet with pay calculator and data storage
 */
public class MainClass {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        EmployeePayData payData = new EmployeePayData();
        PayrollManager payManage = new PayrollManager("payrollProcessed.dat");
        int target;
        char continueScan= 'y';
        double numHours=0;
        double totalPay=0;
        Scanner in = new Scanner(System.in);
        
        payData.loadArray();
       
        System.out.println("Welcome to Parcel pro employee lookup.");
        System.out.println("This program will allow you to search for employees by ID number and enter their hours worked");
        System.out.println("After entering hours worked a record of the employees searched and pay rate will be saved for you in a data file");
        System.out.println("Would you like to begin searching employees now?(y/n)");
         continueScan = in.next().charAt(0);
         
        while (continueScan =='y'|| continueScan == 'Y')
        {
            int foundConferm = -1;
            System.out.println("Please enter the employee ID to search for");
            target = in.nextInt();
            
           
            foundConferm = payData.binSearch(target);
            System.out.println("---------Binary Search-------------");
           if (foundConferm == -1)
           {
               System.out.println("I'm sorry the employee ID " + target + " was not located.");
               System.out.println("--------------------------------");
           }
           else
           {
               System.out.println("Employee ID " + target + " located, please enter hours worked.");
             numHours = in.nextDouble();
             totalPay = numHours * payData.returnEmployeePayBin(foundConferm);
             System.out.printf ("%10s %10s %10s %10s\n", "Employee ID", "Rate", "Hours","Pay");
             System.out.printf ("%10s %10s %10s %10.2f\n", target, payData.returnEmployeePayBin(foundConferm), numHours,totalPay);
             payManage.saveOneRecord(target, payData.returnEmployeePayBin(foundConferm), numHours, totalPay);
             
           }
            
            
            
            
            System.out.println("Search for another Employee?(y/n)");
            continueScan = in.next().charAt(0);
            
        }
        in.close();
        
        System.out.println("Thank you for using Parcel Pro Employee lookup have a nice day.");
        
        
    }
    
}
