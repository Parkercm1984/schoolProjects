/*
 *File:Elevator.java
 *Programmer: Craig Parker
 *Purp: Simulate a basic elevator
 */


package stu.parker.program3.elevator;



public class Elevator 
{
    private int maxFloor;
    private int minFloor;
    private int maxCapacity;
    private int passengers;
    private int currentFloor;
    private int destinationFloor;
    
    public Elevator(int mxFloor, int mnFloor, int mxCap,int curFloor)
    {
        maxFloor = mxFloor;
        minFloor = mnFloor;
        maxCapacity = mxCap;
        currentFloor = curFloor;
    }
    public int getMaxFloor()
    {
        return maxFloor;
    }
    
    public int getMinFloor()
    {
        return minFloor;
    }
    
    public int getMaxCapacity()
    {
        return maxCapacity;
    }
    public int getPassengers()
    {
        return passengers;
    }
    
    public int getCurrentFloor()
    {
        return currentFloor;
    }
    
    public int getDestinationFloor()
    {
        
        return destinationFloor;
    }
    
    public void loadPassengers(int numWaiting)
    {
        int openSpace;
        
        if (numWaiting > maxCapacity)
        {
            openSpace = maxCapacity - passengers;
            System.out.println("WARNING!!! Elevator maximu capacity is " + maxCapacity);
            System.out.println("We appologize for the inconvienance but only  " + openSpace + "People may board the lift for safety reasons.");
                passengers= openSpace + passengers;   
        }
       else
       {
           System.out.println("Now loading " + numWaiting + " passengers");
           passengers = passengers + numWaiting;
       }
       
    }
    
    public void unloadPassengers(int numLeaving)
    {
        System.out.println("Now ariving at floor " + destinationFloor + " of Fawlty Towers please enjoy your stay.");
       if (passengers >= numLeaving)
       {   
            System.out.println(numLeaving + " Passangers now leaving.");
           passengers = passengers - numLeaving;    
       }   
       else
       {
           System.out.println("All passengers departing on " + destinationFloor + " of Fawlty Towers please enjoy your stay.");
           passengers = 0;
       }

    }
    
    public void moveElevator(int destinFloor)
    {
          
            if (destinFloor > maxFloor || destinFloor < minFloor)
            {
                System.out.println("WARNING!!! Selected floor does not exist!  Please make another selection between provided floor peramiters");
                System.out.println("Lowest floor: "  + minFloor +" ----"+ "  Highest floor: " + maxFloor);
                System.out.println("Please select a different floor.");
                        
            }
            else if (destinFloor > currentFloor)
            {
                destinationFloor = destinFloor;
                int i = 1;
                System.out.println("Now departing floor "+ currentFloor);
                while (destinationFloor != currentFloor)
                {
                    currentFloor += i; 
                     System.out.println("Now ariving at floor " + currentFloor);
                     
                }
            }
            else
            {
                 destinationFloor = destinFloor;
                 System.out.println("Now departing floor "+ currentFloor);
                int i = -1;
                while (destinationFloor != currentFloor)
                {
                    currentFloor += + i; 
                     System.out.println("Now ariving at floor " + currentFloor);
                     
                }  
            }    
         
        
    }
}
