/*
 *File:SavingsAccount.java
 *Programmer: Craig Parker
 *Purp: Simulate simple bank savings account with deposits and withdrawls.
 */
package stu.parker.program2.svaccnt;

public class SavingsAccount {
    private String accountNumber;
    private double balance;
    private double intRate;
    
    public SavingsAccount(String actNum,double starBalance,double starIntRate){
    accountNumber = actNum;
    balance = starBalance;
    intRate = starIntRate;
}
    public double getBalance(){
       return balance;
    }
    public String getAccountNumber(){
        return accountNumber;
    }
    public double getIntRate(){
        return intRate;
    }
    public void deposit(double amount){
        balance += amount;
    }
    public void withdrawl(double amount){
        balance -= amount;
    }
    public void setIntRate(double newRate){
        intRate = newRate;
    }
    public void setAccountNumber(String newNumber){
        accountNumber = newNumber;
    }
           
}//end SavingsAccount Class
