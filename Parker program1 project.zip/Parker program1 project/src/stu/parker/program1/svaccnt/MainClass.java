/*
 *File:MainClass.java
 *Programmer: Craig Parker
 *Purp: Simulate simple bank savings account with deposits and withdrawls.
 */
package stu.parker.program1.svaccnt;

import javax.swing.JOptionPane;

public class MainClass {

    public static void main(String[] args) {
      SavingsAccount myAccount = new SavingsAccount("001",0.0,0.005);
      String name;
      double amountDep = 0;
      double amountWid = 0;
      name = JOptionPane.showInputDialog(null,"Please enter your name.");
      amountDep = Double.parseDouble(JOptionPane.showInputDialog(null,"Please enter the amount to start your account."));
      myAccount.deposit(amountDep);
      amountWid = Double.parseDouble(JOptionPane.showInputDialog(null,"Please enter the amount to withdrawl."));
      myAccount.withdrawl(amountWid);
      
    
        
      System.out.println("Thank you " + name + " for banking with us today.");
      System.out.println("Account Number: " + myAccount.getAccountNumber());
      System.out.println("Balance: $" + myAccount.getBalance());
      System.out.println("Interest Rate: %" + myAccount.getIntRate()*100);
    }
    
}//End Main Class
