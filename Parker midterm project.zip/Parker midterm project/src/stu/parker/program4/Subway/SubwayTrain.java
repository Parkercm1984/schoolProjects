//FILE : SubwayTrain.java
//PROG : Craig Parker
//PURP : Class to simulate a city subway, with multiple stops
//and capability of loading and unloading passengers
package stu.parker.program4.Subway;

import java.util.Random;

public class SubwayTrain 
{
	private int stationCount;			//Number of stations serviced by this train
	private int curntStation;			//Number of the station the train is stopped at
	private int destStation;			//Number of the next station to stop at
	private int maxCapacity;			//Max capacity of entire train
	private int numOnBoard;				//Number of pax on train
	private Random ranNumGenerator;
        private int startingStation;
        private int awayStation;
        private int numAtStationOne;
        private int numAtStationX;
	
	public SubwayTrain(int numStations, int maxPersons, int startStation, int awaStation, int nuAtStationOne, int nuAtStationX)
	{
                awayStation = awaStation;
                numAtStationOne = nuAtStationOne;
                numAtStationX = nuAtStationX;
		stationCount = numStations;
		maxCapacity = maxPersons;
                startingStation = startStation;
		curntStation = startStation;
                destStation = curntStation;
		numOnBoard = 0;					//Can't have any pax yet if we just built it!
		//Instantiate the random number object
		ranNumGenerator = new Random();
	}
        public int getAwayStation()
        {
            return awayStation;
        }
        public int getNumAtStationOne()
        {
            return numAtStationOne;
        }
        public int getNumAtStationX()
        {
            return numAtStationX;
        }
      
	public int getCurntStation()
	{
		return curntStation;
	}//END getCurntStation
	
	public int getRandPassengers()
	{
		//Generate a random integer <= maxNum
		return ranNumGenerator.nextInt(maxCapacity + 10);
	}
        public int getRandDepart()
        {
            return ranNumGenerator.nextInt(numOnBoard);
        }
	public int getPassengers()
        {
            return numOnBoard;
        }
        public int getNumStations()
        {
            return stationCount;
        }
        public int getMaxCap()
        {
            return maxCapacity;
        }
        public int getStartingStation()
        {
            return startingStation;
        }
        public int getDestinationStation()
        {
            return destStation;
        }
        public void loadToCapacity(int passWaiting)
        {            
            int openSpace;
           openSpace = maxCapacity - numOnBoard;
           if ((passWaiting + numOnBoard) > maxCapacity)
           {
               System.out.println("Loading " + openSpace + " passangers now all others must wait for next train.");
               numOnBoard = maxCapacity;
               if (startingStation == curntStation)
               {
                   numAtStationOne = numAtStationOne - openSpace;
                   System.out.println(numAtStationOne + " Passangers remain at starting station.");
               }
               else 
               {
                   numAtStationX = numAtStationX - openSpace;
                      System.out.println(numAtStationX + " Passangers remain at destination station.");
               }
           }
           else 
           {
               System.out.println("Loading " + passWaiting + "Passangers now.  Enjoy your ride");
               numOnBoard = numOnBoard + passWaiting;
                if (startingStation == curntStation)
               {
                   numAtStationOne = numAtStationOne - passWaiting;
                    System.out.println(numAtStationOne + " Passangers remain at starting station.");
               }
               else 
               {
                   numAtStationX = numAtStationX - passWaiting;
                   System.out.println(numAtStationX + " Passangers remain at destination station.");
               }
           }
        }
        public void unloadAll()
        {
            System.out.println("Now ariving at destination Station. " + numOnBoard + " Passangers now departing.");
            numOnBoard = 0;
        }
        
	public void moveToStation(int nextStation)
	{
		if (nextStation > stationCount)
                {
                    System.out.println("Warning Station does not exist! " + stationCount +" Is the highest station curently in operation.");
                }
                else
                {
		destStation = nextStation;
		
		//Move the train to the destination
		System.out.printf("Leaving station #%d for station #%d with %d passengers.\n",
				curntStation, destStation, numOnBoard);
		

		//Now update curntStation to the destination
		curntStation = destStation;
                System.out.printf("Now ariving at #%d with %d passengers.\n",
				curntStation,numOnBoard);
                }
	}//END moveToStation
        public void loadPassengers(int numWaiting)
        {
            int openSpace = maxCapacity - numOnBoard;
            int passengersWaiting = numWaiting;
            if ((passengersWaiting + numOnBoard) > maxCapacity)
            {
                System.out.println("Warning! Not enough room on subway. Only " + openSpace+ " May board.  We appologize.");
                numOnBoard = maxCapacity;
                System.out.println(openSpace +" Passengers loaded onto the subway.  Please enjoy your ride.");
            }
            else
            {
                numOnBoard = passengersWaiting + numOnBoard;
                System.out.println(passengersWaiting + " Passangers loaded onto the subway.  Please enjoy your ride.");
            }
        }
        public void unloadPassengers(int numLeaving)
        {
            int numberLeaving = numOnBoard - numLeaving;
            
            if (numLeaving > numOnBoard )
            {
                System.out.println(numOnBoard +" Passengers now leaving the subway.  Have a nice day.");
                numOnBoard = 0;
            }
            else 
            {
                System.out.println(numLeaving + " Passengers now departing the subway. Have a nice day.");
                numOnBoard = numberLeaving; 
            }
        }

}//END class SubwayTrain
