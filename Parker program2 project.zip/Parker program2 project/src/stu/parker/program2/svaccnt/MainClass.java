/*
 *File:MainClass.java
 *Programmer: Craig Parker
 *Purp: Simulate simple bank savings account with deposits and withdrawls.
 */
package stu.parker.program2.svaccnt;


import java.util.Scanner;
import java.text.*;

public class MainClass {

    public static void main(String[] args) {
      SavingsAccount myAccount = new SavingsAccount("001",5000.0,0.003);
      Scanner inputDevice = new Scanner(System.in);
       DecimalFormat  df = new DecimalFormat ("#.##");
      String name;
      char depositRequest;
      char withdrawlRequest;
      double amountDep;
      double amountWid;
      double intBalanceStart;
      double intBalanceEnd;
      double intEarned;
      int i = 0;
      
  System.out.println("Welcome to Carolina Banking west branch");
  System.out.print("Please enter your name >>");
  name = inputDevice.nextLine();
  System.out.println("Thank you "+ name + " For banking with us today");
  System.out.println("******Account Details******");
  System.out.println("Account Number: " + myAccount.getAccountNumber());
  System.out.println("Balance: " + myAccount.getBalance());
  System.out.println("Interest Rate: " + myAccount.getIntRate()*100 + "%");
  System.out.println("\n Would you like to make a deposit with us today " + name + "?" + "(y/n)");
  depositRequest = inputDevice.next().charAt(0);
  
  if (depositRequest == 'y' || depositRequest == 'Y')
  {
      System.out.println("How much money would you like to deposit today " + name + "?");
      amountDep = inputDevice.nextDouble();
      myAccount.deposit(amountDep);
  }
  System.out.println("\n Would you like to make a withdrawl with us today " + name + "?" + "(y/n)");
  withdrawlRequest = inputDevice.next().charAt(0);
  
  if (withdrawlRequest == 'y' || withdrawlRequest == 'Y')
  {
      System.out.println("How much money would you like to withdrawl today " + name + "?");
      amountWid = inputDevice.nextDouble();
      myAccount.withdrawl(amountWid);
  }
 
  System.out.println("Thank you " + name + "for your business today.");
  System.out.println("******Account Details******");
  System.out.println("Account Number: " + myAccount.getAccountNumber());
  System.out.println("Balance: " + myAccount.getBalance());
  System.out.println("Interest Rate: " + myAccount.getIntRate()*100 + "%");
  
  intBalanceStart = myAccount.getBalance();
  System.out.println("****Yearly interest rate report****");
  System.out.println("Month     Starting     Interest     Ending");
  System.out.println("#         Balance       Earned      Balance");
  while (i < 12)
  {
   i += 1;
   intBalanceEnd = (intBalanceStart * myAccount.getIntRate()) + intBalanceStart;
   intEarned = intBalanceEnd - intBalanceStart;
   System.out.println(i +"         " + df.format(intBalanceStart) + "          " + df.format(intEarned) + "       " + df.format(intBalanceEnd));
   intBalanceStart = intBalanceEnd;
  }
  

  
    
    }
    
}//End Main Class
