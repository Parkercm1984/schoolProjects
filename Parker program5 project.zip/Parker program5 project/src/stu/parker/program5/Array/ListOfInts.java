/*
 * Programmer: Craig Parker
 * File:ListOfInts
 * Purp: To load a data file of intagers into an array and manipulate it in various ways.
 */
package stu.parker.program5.Array;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;


public class ListOfInts
{
    private int[] ListOfIntsArray = new int [100];
    private int arrayLength;
    double Average= 0;
    int aboveAvgCount = 0;
    int lowestInt;
  public ListOfInts()
  {
      
  }  
  
  public void loadArray()
  {
     int arrayPosition = 0;
     
     
     try
     {
         String fileName = "program5.dat";
         Scanner inFile = new Scanner(new FileInputStream(fileName));
     
         while (inFile.hasNext())
         {
             ListOfIntsArray[arrayPosition] = inFile.nextInt();
             ++ arrayPosition;
         }
         inFile.close();
         
     } 
     catch (FileNotFoundException ex) 
      {  
         arrayPosition = -1;
          Logger.getLogger(ListOfInts.class.getName()).log(Level.SEVERE, null, ex);
      } 
     arrayLength = arrayPosition;
  }  
  public void displayArray()
  {
    int i = 0;
    
    while (i < arrayLength)
    {
        System.out.println(ListOfIntsArray[i]);
        ++i;
    }

  }
  public void averageArray()
  {
     int runningTotal = 0;
     int i = 0;
    
     while (i < arrayLength)
     {
         runningTotal = ListOfIntsArray[i] + runningTotal;
         ++i;
     }
     Average = runningTotal / arrayLength;
  }
  public void coutAboveAvg()
  {
      int i = 0;
      
      
      while (i < arrayLength)
      {
          if (ListOfIntsArray[i]> Average)
          {
           ++aboveAvgCount;   
          }
          ++i;
      }
    
  }
  public void findMinInt()
  {
      int i = 0;
      lowestInt = ListOfIntsArray[0];
      
      while (i < arrayLength)
      {
        if (lowestInt > ListOfIntsArray[i])
        {
          lowestInt = ListOfIntsArray[i];
        }
        ++i;
      }
      
  }
  
  public double getAverage()
  {
      return Average;
  }
  public int getAboveAvgCount()
  {
      return aboveAvgCount;
  }
  public int getMinInt()
  {
      return lowestInt;
  }
    
}//end ListOfInts Class
