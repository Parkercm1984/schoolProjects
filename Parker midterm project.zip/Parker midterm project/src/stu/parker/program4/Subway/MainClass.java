//FILE : MainClass.java
//PROG : Craig Parker
//PURP : Simulate city subway train with moves between station
//Does not yet have the capability to load or unload passengers
package stu.parker.program4.Subway;
import java.util.Scanner;
public class MainClass 
{
	public static void main(String[] args) 
	{
		final int STATIONCOUNT = 30;
                Scanner in = new Scanner(System.in);
                
                
                System.out.println("Welcome to downtown Subway Express rout.  Please input your station destionation.");
                int desiredStation = in.nextInt();
                System.out.println("How many passangers to load at starting station?");
                int startingPass = in.nextInt();
                System.out.println("How many passangers to load at destination station?");
		int destinPass = in.nextInt();
               if (desiredStation > STATIONCOUNT)
               {
                   System.out.println("Warning Station does not exist!");
               }
               else
               {
                   SubwayTrain expreessLine = new SubwayTrain(STATIONCOUNT ,100, 1, desiredStation, startingPass, destinPass);
                   
                   while (expreessLine.getNumAtStationOne() > 0 || expreessLine.getNumAtStationX() > 0)
                   {
                       expreessLine.loadToCapacity(expreessLine.getNumAtStationOne());
                       expreessLine.moveToStation(desiredStation);
                       expreessLine.unloadAll();
                       
                       expreessLine.loadToCapacity(expreessLine.getNumAtStationX());
                       expreessLine.moveToStation(1);
                       expreessLine.unloadAll();
                   }
                  System.out.println("Returned to home station.  Shutting down service.");
               }
		 
                

	}//END main

}//END MainClass
