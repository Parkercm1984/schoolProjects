package stu.parker.program6.arraySearch;

import java.util.Scanner;

/*
 * Programmer:Craig Parker
 * File: MainClass.java
 * Purp: Exicute binary and standard searches of arrays
 */
public class MainClass {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        EmployeePayData payData = new EmployeePayData();
        int target;
        char continueScan= 'y';
        Scanner in = new Scanner(System.in);
        
        payData.loadArray();
       
        System.out.println("Welcome to Parcel pro employee lookup.");
        
        while (continueScan =='y'|| continueScan == 'Y')
        {
            int foundConferm = -1;
            System.out.println("Please enter the employee ID to search for");
            target = in.nextInt();
            
            payData.seqSearch(target);
           foundConferm= payData.getFound();
           System.out.println("---------Sequential Search-------------");
           if (foundConferm == -1)
           {
               System.out.println("I'm sorry the employee ID " + target + " was not located.");
           }
           else
           {
               System.out.println("Employee ID: " + target);
               System.out.println("Hourly Pay: " + payData.returnEmployeePaySeq() );
           }
            System.out.println("--------------------------------");
            
            payData.binSearch(target);
            foundConferm = payData.getMid();
            System.out.println("---------Binary Search-------------");
           if (foundConferm == -1)
           {
               System.out.println("I'm sorry the employee ID " + target + " was not located.");
           }
           else
           {
               System.out.println("Employee ID: " + target);
               System.out.println("Hourly Pay: " + payData.returnEmployeePayBin() );
           }
            System.out.println("--------------------------------");
            
            
            
            System.out.println("Search for another Employee?(y/n)");
            continueScan = in.next().charAt(0);
            
        }
        in.close();
        
        System.out.println("Thank you for using Parcel Pro Employee lookup have a nice day.");
        
        
    }
    
}
