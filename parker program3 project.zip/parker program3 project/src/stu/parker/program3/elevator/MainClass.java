/*
 *File:MainClass.java
 *Programmer: Craig Parker
 *Purp: Simulate a basic elevator
 */

package stu.parker.program3.elevator;


public class MainClass 
{
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
     Elevator fawltyTowersE1= new Elevator(99, 1, 18, 1);
     
     System.out.println("Welcome to Fawlty Towers Elevator one please enjoy your stay with us.");
     
     fawltyTowersE1.loadPassengers(10);
     fawltyTowersE1.moveElevator(88);
     fawltyTowersE1.unloadPassengers(4);
     
     fawltyTowersE1.loadPassengers(22);
     fawltyTowersE1.moveElevator(77);
     fawltyTowersE1.unloadPassengers(45);
     
     fawltyTowersE1.loadPassengers(5);
     fawltyTowersE1.moveElevator(-594);
     fawltyTowersE1.moveElevator(45);
     fawltyTowersE1.unloadPassengers(4);
     
     fawltyTowersE1.loadPassengers(8);
     fawltyTowersE1.moveElevator(121);
     fawltyTowersE1.moveElevator(99);
     fawltyTowersE1.unloadPassengers(11);
     
    
     
    
     
     
     
     
     
     
     
    }
    
}
