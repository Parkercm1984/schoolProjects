package stu.parker.program5.Array;

/*
 * Programmer: Craig Parker
 * File:MainClass
 * Purp: To load a data file of intagers into an array and manipulate it in various ways.
 */

public class MainClass {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ListOfInts currentList = new ListOfInts();
        
        currentList.loadArray();       
        currentList.displayArray();
        currentList.averageArray();
        currentList.coutAboveAvg();
        currentList.findMinInt();
        
        System.out.println("Average: " +currentList.getAverage());
        System.out.println("Above Average count: " + currentList.getAboveAvgCount());
        System.out.println("Lowest Int: "+ currentList.getMinInt());
       
    }
    
}
