/*
 * Programmer:Craig Parker
 * File: EmployeePayData.java
 * Purp: Provide a searchable employee lookup compleet with pay calculator and data storage
 */
package stu.parker.finalprogram.payrollSearch;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;


public class EmployeePayData {
    private int[] listOfIntsArray = new int [1000];
    private double[] listOfDoublesArray = new double [1000];
    private int arrayLength;
   
    
      
    public EmployeePayData()
    {
        
    }//constructor
    
    public void loadArray()
  {
     int arrayPosition = 0;
     
     
     try
     {
         String fileName = "employeePay.dat";
         Scanner inFile = new Scanner(new FileInputStream(fileName));
     
         while (inFile.hasNext())
         {
             listOfIntsArray[arrayPosition] = inFile.nextInt();
             listOfDoublesArray[arrayPosition] = inFile.nextDouble();
             ++ arrayPosition;
         }
         inFile.close();
         
     } 
     catch (FileNotFoundException ex) 
      {  
         arrayPosition = -1;
          Logger.getLogger(EmployeePayData.class.getName()).log(Level.SEVERE, null, ex);
      } 
     arrayLength = arrayPosition;
  }//end loadArray
    
     
   
    public int binSearch(int target)
    {
        int first = 0;
        int last = arrayLength -1;
        int binFound = 0;
        int mid=0;
        
        while (first <= last && binFound ==0)
        {
             mid = (first+last)/2;
           if (listOfIntsArray[mid] == target)
           {
              binFound = 1; 
           }
           else if (listOfIntsArray[mid] < target)
           {
               first = mid+1;
           }
           else
           {
               last = mid -1;
           }
        }   
           if (binFound == 0)
           {
               mid= -1;
           }
            
        return mid;
    }//end binSearch
       
               
    public double returnEmployeePayBin(int foundLoc)
            {
              double employeePay = listOfDoublesArray[foundLoc];
              return employeePay;
            }
 
    
   /*public void printList()
   {
       int i=0;
       while (i<arrayLength)
       {
           System.out.println(ListOfDoublesArray[i]);
           System.out.println(ListOfIntsArray[i]);
           ++i;
       }
       
   }
     */   
    
}//End of EmployeePayData Class
