
/*
 * Programmer:Craig Parker
 * File: PayrollManager.java
 * Purp: Provide a searchable employee lookup compleet with pay calculator and data storage
 */
package stu.parker.finalprogram.payrollSearch;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;


public class PayrollManager {
    String saveFile;
    
    public PayrollManager(String file)
    {
       saveFile = file;
        
    }//constructor
    
    
    
    public void saveOneRecord(int empID,double rate,double hours,double pay)
    {
        try
	{
		
		PrintWriter myPW = new PrintWriter (new FileWriter(saveFile, true));
		Scanner myScanner = new Scanner (System.in);
                
            myPW.printf ("%10s %10s %10s %10s \r\n", "Employee ID", "Rate", "Hours","Pay");
            myPW.printf ("%10s %10s %10s %10.2f \r\n", empID, rate, hours,pay);
            myPW.close();
			
	
	}
	catch (IOException ex)
	{
		ex.printStackTrace();
	}
        
        
    }//end saveOneRecord
    
    
    
    
}//end of Class
