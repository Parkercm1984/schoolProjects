//FILE : MainClass.java
//PROG : Craig Parker
//PURP : Simulate city subway train with moves between station
//Does not yet have the capability to load or unload passengers
package stu.parker.program4.subway;

public class MainClass 
{
	public static void main(String[] args) 
	{
		final int STATIONCOUNT = 30;
		SubwayTrain downtownExpress = new SubwayTrain(STATIONCOUNT, 200, 1);
               
		 
                
		System.out.println("All aboard the BIG CITY Subway!\n\n");
                   
		for (int ct = 0; ct < STATIONCOUNT; ++ct)
		{
                        downtownExpress.loadPassengers(downtownExpress.getRandPassengers());
			downtownExpress.moveToStation(downtownExpress.getCurntStation() + 1);
                        downtownExpress.unloadPassengers(downtownExpress.getRandDepart());
                        System.out.println("All aboard the BIG CITY Subway!\n\n");
              
		} 
                System.out.println("Now returning to home station.  This is the final stop today");
                downtownExpress.loadPassengers(downtownExpress.getRandPassengers());
                downtownExpress.moveToStation(downtownExpress.getStartingStation());
                downtownExpress.unloadPassengers(downtownExpress.getPassengers());

	}//END main

}//END MainClass
